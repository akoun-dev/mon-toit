-- seed.sql
-- Comprehensive Seed Data for Mon Toit Application
--
-- ⚠️ IMPORTANT: Ce fichier ne crée plus les comptes utilisateurs!
-- Utilisez le script: npm run create-test-users
--
-- 📋 COMPTES DE TEST DISPONIBLES:
--
-- 🔧 ADMIN:
--    Email: admin@mon-toit.ci
--    Mot de passe: admin123
--    Tableau de bord: http://localhost:8080/admin
--
-- 🏠 PROPRIÉTAIRES (9 comptes):
--    kouadio.jean@mon-toit.ci (proprietaire123)
--    marie.aya@mon-toit.ci (proprietaire123)
--    koffi.alain@mon-toit.ci (proprietaire123)
--    patricia.kouame@mon-toit.ci (proprietaire123)
--    adou.rosine@mon-toit.ci (proprietaire123)
--    traore.sami@mon-toit.ci (proprietaire123)
--    konan.emma@mon-toit.ci (proprietaire123)
--    nguessan.fred@mon-toit.ci (proprietaire123)
--    kone.adama@proprietaire.ci (proprietaire123)
--
-- 🏠 LOCATAIRES (4 comptes):
--    yao.konan@mon-toit.ci (locataire123)
--    aminata.diarra@mon-toit.ci (locataire123)
--    dr.yeo@mon-toit.ci (locataire123)
--    toure.mohamed@locataire.ci (locataire123)
--
-- 🏢 AGENCES (2 comptes):
--    contact@agence-cocody.ci (agence123)
--    info@ankou-realestate.ci (agence123)
--
-- 🤝 TIERS DE CONFIANCE (1 compte):
--    notaire.konan@mon-toit.ci (tiers123)
--
-- Note: Les comptes utilisateurs doivent être créés avec le script JS.
-- Ce seed ne contient que les données de test (propriétés, rôles, etc.)

-- ⚠️ NOTE: Les utilisateurs et profils ne sont plus créés ici.
-- Utilisez le script: npm run create-test-users pour créer les utilisateurs avec leurs profils

-- Note: Profiles are now created by the create-test-users script
-- This avoids foreign key constraint violations since profiles must reference auth.users

-- Note: Properties are now created by the create-test-users script after users and profiles are created
-- This avoids foreign key constraint violations since properties must reference profiles

-- Create sample notifications (will be associated with users via the script)
DO $$
BEGIN
  -- Create notifications template that will be copied for each user
  -- The script will create actual notifications for each user

  RAISE NOTICE '✓ Structure des notifications préparée (sera créée par le script)';
END $$;

-- Final summary
DO $$
BEGIN
  RAISE NOTICE '=========================================';
  RAISE NOTICE '=== SEED GLOBAL TERMINÉ AVEC SUCCÈS ===';
  RAISE NOTICE '=========================================';
  RAISE NOTICE '';
  RAISE NOTICE '⚠️ IMPORTANT: Les comptes utilisateurs doivent être créés avec:';
  RAISE NOTICE '   npm run create-test-users';
  RAISE NOTICE '';
  RAISE NOTICE '📋 COMPTES DE TEST DISPONIBLES:';
  RAISE NOTICE '';
  RAISE NOTICE '👑 ADMINISTRATEUR:';
  RAISE NOTICE '   Email: admin@mon-toit.ci';
  RAISE NOTICE '   Mot de passe: admin123';
  RAISE NOTICE '';
  RAISE NOTICE '🏠 PROPRIÉTAIRES (exemples):';
  RAISE NOTICE '   kouadio.jean@mon-toit.ci (proprietaire123)';
  RAISE NOTICE '   marie.aya@mon-toit.ci (proprietaire123)';
  RAISE NOTICE '   koffi.alain@mon-toit.ci (proprietaire123)';
  RAISE NOTICE '';
  RAISE NOTICE '🏠 LOCATAIRES:';
  RAISE NOTICE '   yao.konan@mon-toit.ci (locataire123)';
  RAISE NOTICE '   aminata.diarra@mon-toit.ci (locataire123)';
  RAISE NOTICE '';
  RAISE NOTICE '🏢 AGENCES:';
  RAISE NOTICE '   contact@agence-cocody.ci (agence123)';
  RAISE NOTICE '   info@ankou-realestate.ci (agence123)';
  RAISE NOTICE '';
  RAISE NOTICE '🤝 TIERS DE CONFIANCE:';
  RAISE NOTICE '   notaire.konan@mon-toit.ci (tiers123)';
  RAISE NOTICE '=========================================';
END $$;