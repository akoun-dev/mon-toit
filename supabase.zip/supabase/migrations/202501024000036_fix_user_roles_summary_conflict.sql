-- Migration: Fix user_roles_summary conflict
-- Description: This migration is now a no-op since the table was properly created in migration 202501024000032
-- The user_roles_summary table has already been created as a proper table with all necessary structure

-- This migration is intentionally left empty as the functionality has been moved to migration 202501024000032